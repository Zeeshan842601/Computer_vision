# Import commands for terminal:
# pip install opencv-python
# pip install numpy
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

def background_subtraction(image):
    """
    This function estimates and subtracts the background of the given image.
    Args:
    - image: Input image in BGR format
    Returns:
    - foreground: Image with background subtracted
    """
    try:
        # Create a background subtractor object
        back_sub = cv2.createBackgroundSubtractorMOG2()

        # Apply background subtraction
        foreground = back_sub.apply(image)

        return foreground

    except Exception as e:
        print(f"An error occurred during background subtraction: {e}")

# Main code to load the image and apply background subtraction
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")
        
        # Estimate and subtract the background
        foreground = background_subtraction(image)

        # Display original and foreground images
        plt.figure(figsize=(10, 5))

        plt.subplot(1, 2, 1)
        plt.title('Original Image')
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title('Foreground (Background Subtracted)')
        plt.imshow(foreground, cmap='gray')
        plt.axis('off')

        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")