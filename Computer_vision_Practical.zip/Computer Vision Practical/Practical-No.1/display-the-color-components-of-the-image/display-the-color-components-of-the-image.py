# Import commands for terminal:
# pip install opencv-python
# pip install numpy

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for array manipulation

# Function to split and display the color components of the image
def display_color_components(image):
    """
    This function splits the image into its Red, Green, and Blue color components and displays each component separately.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Split the image into Blue, Green, and Red components
        B, G, R = cv2.split(image)

        # Merge the channels with zeros to isolate the color components
        zeros = np.zeros(image.shape[:2], dtype="uint8")

        # Display the Blue component
        blue_component = cv2.merge([B, zeros, zeros])
        cv2.imshow('Blue Component', blue_component)

        # Display the Green component
        green_component = cv2.merge([zeros, G, zeros])
        cv2.imshow('Green Component', green_component)

        # Display the Red component
        red_component = cv2.merge([zeros, zeros, R])
        cv2.imshow('Red Component', red_component)

    except Exception as e:
        print(f"An error occurred while processing the image: {e}")

# Main code to load the image and display color components
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Display the original image
        cv2.imshow('Original Image', image)

        # Display the color components (Blue, Green, Red)
        display_color_components(image)

        # Wait for the user to press a key and then close the display windows
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
