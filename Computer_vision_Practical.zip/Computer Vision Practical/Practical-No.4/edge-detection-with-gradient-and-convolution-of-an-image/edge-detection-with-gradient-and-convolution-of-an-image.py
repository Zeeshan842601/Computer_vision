# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

# Function to perform edge detection using the Sobel operator
def edge_detection(image):
    """
    This function applies the Sobel operator for edge detection.
    Args:
    - image: Input image in grayscale
    Returns:
    None
    """
    try:
        # Calculate the gradient in the x and y direction
        sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=5)  # Gradient in x direction
        sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=5)  # Gradient in y direction

        # Calculate the magnitude of gradients
        gradient_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
        gradient_magnitude = np.uint8(np.clip(gradient_magnitude, 0, 255))  # Convert to uint8

        # Display original and edge-detected images
        plt.figure(figsize=(10, 5))

        plt.subplot(1, 2, 1)
        plt.title('Original Image')
        plt.imshow(image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title('Edge Detected Image')
        plt.imshow(gradient_magnitude, cmap='gray')
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred during edge detection: {e}")

# Main code to load the image and perform edge detection
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Convert to grayscale
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")
        
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply edge detection
        edge_detection(gray_image)

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
